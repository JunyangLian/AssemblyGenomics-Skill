import json
from pathlib import Path
from collections import Counter, defaultdict

BASE = Path('D:/1_yanjiusheng/GenomeAssembly Copilot/bench/inspect_adapter/work/t3_blind_review')
PACKETS = BASE / 'packets'
reports = {}
for num in range(1, 15):
    case = f'R{num:03}'
    artifacts = PACKETS / case / 'artifacts'
    rows = []
    for line_no, line in enumerate((artifacts / 'models.gff3').read_text(encoding='utf-8-sig').splitlines(), 1):
        if not line or line.startswith('#'):
            continue
        f = line.split('\t')
        assert len(f) == 9, (case, line_no, f)
        attrs = dict(x.split('=', 1) for x in f[8].split(';') if '=' in x)
        rows.append(dict(line=line_no, seqid=f[0], type=f[2], start=int(f[3]), end=int(f[4]), strand=f[6], attrs=attrs))
    ids = defaultdict(list)
    for row in rows:
        if 'ID' in row['attrs']:
            ids[row['attrs']['ID']].append(row)
    proteins = []
    for line_no, line in enumerate((artifacts / 'proteins.faa').read_text(encoding='utf-8-sig').splitlines(), 1):
        if line.startswith('>'):
            proteins.append(dict(line=line_no, token=line[1:].split()[0], residues=0))
        elif line.strip():
            assert proteins, (case, line_no)
            proteins[-1]['residues'] += len(''.join(line.split()))
    token_counts = Counter(p['token'] for p in proteins)
    errors = []
    parent_edges = 0
    for row in rows:
        a = row['attrs']
        expected_parent_type = {'mRNA':'gene', 'exon':'mRNA', 'CDS':'mRNA'}.get(row['type'])
        parent_names = a.get('Parent','').split(',') if a.get('Parent') else []
        if expected_parent_type and not parent_names:
            errors.append(dict(kind='parent_missing_attribute', line=row['line']))
        for parent_name in parent_names:
            parent_edges += 1
            parent_rows = ids.get(parent_name, [])
            if not parent_rows:
                errors.append(dict(kind='parent_unresolved', line=row['line'], parent=parent_name))
                continue
            if len(parent_rows) != 1:
                errors.append(dict(kind='parent_ambiguous', line=row['line'], parent=parent_name, parent_lines=[p['line'] for p in parent_rows]))
            for p in parent_rows:
                for kind, mismatch in [
                    ('parent_type', expected_parent_type != p['type']),
                    ('parent_seqid', row['seqid'] != p['seqid']),
                    ('parent_strand', row['strand'] != p['strand']),
                    ('parent_containment', not (p['start'] <= row['start'] <= row['end'] <= p['end']))]:
                    if mismatch:
                        errors.append(dict(kind=kind,line=row['line'],parent=parent_name,parent_line=p['line']))
        if row['type'] == 'CDS':
            pid = a.get('protein_id')
            if not pid:
                errors.append(dict(kind='protein_id_missing', line=row['line']))
            elif token_counts[pid] != 1:
                errors.append(dict(kind='protein_id_not_unique_match',line=row['line'],protein_id=pid,faa_matches=token_counts[pid]))
    cds = [r for r in rows if r['type'] == 'CDS']
    pids = {r['attrs'].get('protein_id') for r in cds if r['attrs'].get('protein_id')}
    for p in proteins:
        if p['token'] not in pids:
            errors.append(dict(kind='faa_unmatched',line=p['line'],token=p['token']))
    counts = dict(cds_rows=len(cds),exon_rows=sum(r['type']=='exon' for r in rows),gene_rows=sum(r['type']=='gene' for r in rows),mrna_rows=sum(r['type']=='mRNA' for r in rows),protein_records=len(proteins),protein_residues=sum(p['residues'] for p in proteins),unique_cds_ids=len({r['attrs'].get('ID') for r in cds if r['attrs'].get('ID')}))
    stated = json.loads((artifacts/'record_counts.json').read_text(encoding='utf-8-sig'))
    mismatched_counts = {k:dict(stated=v,computed=counts.get(k)) for k,v in stated.items() if counts.get(k)!=v}
    reports[case] = dict(rows=rows,proteins=proteins,counts=counts,unique_protein_ids=len(pids),stated_counts=stated,count_mismatches=mismatched_counts,errors=errors,parent_edges=parent_edges)
(BASE/'blind_check_results.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2),encoding='utf-8')
for case, r in reports.items():
    print(case, json.dumps({k:r[k] for k in ['counts','unique_protein_ids','count_mismatches','errors','parent_edges']},ensure_ascii=False))
