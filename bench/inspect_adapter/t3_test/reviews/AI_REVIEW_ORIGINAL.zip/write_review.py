import json
import re
from pathlib import Path
from collections import defaultdict, Counter

BASE = Path('D:/1_yanjiusheng/GenomeAssembly Copilot/bench/inspect_adapter/work/t3_blind_review')
PACKETS = BASE / 'packets'
reports = json.loads((BASE/'blind_check_results.json').read_text(encoding='utf-8'))
schema = json.loads((PACKETS/'schema.json').read_text(encoding='utf-8-sig'))

def ev(pointer, observation):
    return dict(pointer=pointer, observation=observation)

cases = {}
notes = [
    '# AI 公开资料盲审记录',
    '',
    '审查者是 AI（Codex child agent inheriting parent model; exact provider model ID unavailable），不是真人专家。上下文为 fork_none/public_only。无 gold、答案映射或历史评分输入。仅访问 packets/schema.json、packets/system.txt、R001–R014/task.md 和各自 artifacts 的三个公开文件，以及本次自己创建的检查脚本和结果。未读取 meta.json、expected.json、PRIVATE_MAPPING.json、题库构建器或其他仓库资料。',
    '',
    '本次隔离是执行中的访问约束，没有操作系统强制的独立沙箱或访问审计证明。默认 exec_command 启动失败，Node REPL 两次启动失败；后改用获准的 require_escalated 本地 PowerShell 读取公开文件并执行本地 Python。没有联网，没有调用其他或付费模型服务，没有修改题面或产物。',
    '',
    '## 执行方法',
    '',
    'blind_check.py 用 Python 标准库遍历全部 GFF 非注释行（按原文件一基行号）、全部 FAA header 和全部序列行。读取第九列中的 ID/Parent/protein_id；建立 ID 索引后对每个 Parent 检查存在性、类型（mRNA→gene，exon/CDS→mRNA）、seqid、strand，以及父.start ≤ 子.start ≤ 子.end ≤ 父.end。每行 CDS 的 protein_id 均与 FAA header 第一个 token 做区分大小写、保留版本的精确连接，并反向检查无游离 FAA 记录和无重复 FAA token。',
    '',
    'CDS 行数与 unique CDS ID 分别计算；同时独立计算 unique protein_id 数。完整 FAA 序列按非空白字符统计 residues，再与 record_counts.json 的七个顶层统计字段逐一比较。复核了 compact 全记录显示、全部检查错误与原始证据位置；终端大批显示有截断，机械解析不依赖截断输出，R007 的局部显示另行完整读取。write_review.py 检查每题输出只有 schema 的七字段、字段类型和枚举，并校验 evidence 路径、实际文件与一基行号/JSON 顶层字段。',
    '',
    '没有以 Name、Dbxref、CDS ID、orig_protein_id 替代 protein_id，没有执行去版本或相似名称补配。允许的 partial、异构体和重复多片段 CDS ID 未被当作异常。未检查翻译、phase 生物学正确性、功能、全基因组质量或历史上游过程，因为 task.md:5、task.md:9 明示这些范围限制。',
    '',
    '## 合同与 schema 表达限制',
    '',
    '合同对本批资料的阻断条件足够明确，未发现足以改变 pass/block 的合同歧义。“两套完整编码 gene 特征块”按全部层级记录已给出的文件完整性理解；task.md:9 明确允许 partial，因此不把 complete block 理解为强制生物学全长。',
    '',
    'schema 的 root_cause 是有限标签：缺失 Parent 可同时被描述为标识引用不匹配或层级错误；本审查采用 gff_hierarchy_error 表示可观测的未解析层级边，不把它归因为上游重命名、丢基因或别的历史事故。它不区分坐标越界的具体方向、游离 FAA、同组多个错误 CDS 行，或正常的多片段/partial/异构体；这些事实在 evidence 和本笔记补记。没有运行日志，无法确定应该修改哪一侧的 ID、Parent 或坐标；修复必须依据可信来源，而不是自动套用相似名称。',
    '',
    '所有记录计数字段均与直接重算一致。计数一致是次级事实，不能消除必要连接或层级缺陷。全部问题是启动前输入合同，不存在已完成结果或可恢复旧版，因此所有阻断判定均为 block，不是 rollback。',
    '',
    '## 逐题记录',
    '',
    '|题号|判定|GFF gene/mRNA/exon/CDS 行|unique CDS ID / unique protein_id / FAA|residues|Parent 边|计数核对|',
    '|---|---|---|---|---|---|---|',
]

for case, report in reports.items():
    rows = report['rows']
    by_line = {r['line']:r for r in rows}
    id_rows = defaultdict(list)
    for row in rows:
        id_rows[row['attrs'].get('ID')].append(row)
    cds_groups = defaultdict(list)
    for row in rows:
        if row['type']=='CDS':
            cds_groups[row['attrs']['ID']].append(row)
    for group in cds_groups.values():
        assert len({r['attrs'].get('protein_id') for r in group})==1
        assert len({r['attrs'].get('Parent') for r in group})==1
        assert len({r['seqid'] for r in group})==1
        assert len({r['strand'] for r in group})==1
    assert not report['count_mismatches']
    errors = report['errors']
    evidence = [ev('task.md:7','消费者要求 Parent 层级、同 seqid/同链、闭区间包含，以及每行 CDS protein_id 与 FAA 首 token 精确一一连接。')]
    uncertainties = []
    secondary = []
    if not errors:
        verdict, defect, cause = 'pass','none','none'
        action = '按题面范围可继续下游启动；保留当前精确 ID 连接与 Parent 层级检查，partial、异构体或重复的多片段 CDS ID 不需要修复。'
        for row in rows:
            if row['type']=='mRNA':
                parent = id_rows[row['attrs']['Parent']][0]
                evidence.append(ev(f"artifacts/models.gff3:{row['line']}",f"mRNA ID={row['attrs']['ID']} 的 Parent={parent['attrs']['ID']} 可在第 {parent['line']} 行 gene 解析，seqid={row['seqid']}、strand={row['strand']} 相同，闭区间 {row['start']}–{row['end']} 位于父区间 {parent['start']}–{parent['end']} 内。"))
        for group in cds_groups.values():
            first = group[0]
            pid = first['attrs']['protein_id']
            p = next(p for p in report['proteins'] if p['token']==pid)
            evidence.append(ev(f"artifacts/models.gff3:{first['line']}",f"该 CDS 行的 protein_id={pid}；同 ID 共 {len(group)} 个 CDS 片段逐行使用这一 protein_id，均成功精确连接同一 FAA 记录。"))
            evidence.append(ev(f"artifacts/proteins.faa:{p['line']}",f"FAA header 第一个 token 为 {p['token']}，且本文件中这一 token 仅出现一次。"))
        secondary.append(f"全记录检查 {report['parent_edges']} 条 Parent 边均通过存在性、类型、seqid、strand 与闭区间包含；全部 CDS 行及全部 FAA 双向精确连接通过。")
    else:
        verdict = 'block'
        kinds = {e['kind'] for e in errors}
        if 'protein_id_not_unique_match' in kinds:
            defect,cause = 'gff_faa_link_missing','id_mismatch'
            bad = [e for e in errors if e['kind']=='protein_id_not_unique_match']
            missing_pids = sorted({e['protein_id'] for e in bad})
            for error in bad:
                row=by_line[error['line']]
                evidence.append(ev(f"artifacts/models.gff3:{row['line']}",f"CDS 的实际 protein_id={error['protein_id']}，完整 FAA header 首 token 集中没有精确匹配；Name={row['attrs'].get('Name')} 和 ID={row['attrs'].get('ID')} 不是消费者声明的连接键。"))
            for error in errors:
                if error['kind']=='faa_unmatched':
                    evidence.append(ev(f"artifacts/proteins.faa:{error['line']}",f"FAA header 首 token 为 {error['token']}，没有同值的 CDS protein_id 组，形成反向游离记录。"))
            action = '停止下游启动；依据可信来源统一受影响 CDS 组每一行的 protein_id 与对应 FAA 首 token，或补齐/重导出确实属于该 protein_id 的蛋白；修复后重新验证全部 CDS 行和 FAA 双向一一连接，再继续。不得用 Name/CDS ID 或自动去版本绕过检查。'
            uncertainties.append('确定存在精确连接键不一致；无法仅凭公开文件判断 GFF protein_id 还是 FAA header 才是应保留的正确标识，也无法推断上游生成过程。')
            secondary.append('其余全部 Parent 边检查通过。数值上 unique CDS ID、unique protein_id 与 FAA 记录数相等，但键集合不相等。')
        elif 'parent_unresolved' in kinds:
            defect,cause = 'gff_reference_unresolved','gff_hierarchy_error'
            for error in errors:
                row=by_line[error['line']]
                evidence.append(ev(f"artifacts/models.gff3:{row['line']}",f"mRNA ID={row['attrs']['ID']} 的 Parent={error['parent']} 在完整 GFF ID 集合中不存在，gene→mRNA 的引用不可解析。"))
                candidates = [r for r in rows if r['type']=='gene' and r['seqid']==row['seqid'] and r['strand']==row['strand'] and r['start']<=row['start']<=row['end']<=r['end']]
                for p in candidates:
                    evidence.append(ev(f"artifacts/models.gff3:{p['line']}",f"可见 gene 的 ID={p['attrs']['ID']}，不是 mRNA 写出的 Parent={error['parent']}；坐标或名称相近不能替代声明的 Parent 精确引用。"))
            action='停止下游启动；从可信来源确认缺失 Parent 引用的目标。若为引用字段错误，修正 mRNA Parent；若确实缺父记录，补齐类型、seqid、strand 和包含范围正确的 gene。重新检查全部层级和蛋白连接通过后再继续。'
            uncertainties.append('可确认 Parent 未解析；未提供生成日志或权威目标映射，不能断言这是上游重命名还是漏写记录。root_cause 的 id_mismatch 与 gff_hierarchy_error 标签存在语义重叠，本审查选后者表达结构引用错误。')
            secondary.append('全部 CDS protein_id 与 FAA 记录双向精确连接通过；其余可解析 Parent 边的类型、seqid、strand 和包含检查通过。')
        elif 'parent_containment' in kinds:
            defect,cause='gff_hierarchy_inconsistent','gff_hierarchy_error'
            for error in errors:
                row,p=by_line[error['line']],by_line[error['parent_line']]
                evidence.append(ev(f"artifacts/models.gff3:{row['line']}",f"CDS 闭区间 {row['start']}–{row['end']} 完全超出父 mRNA 右边界 {p['end']}，其起点为父终点加 1；Parent={error['parent']} 虽可解析，但违反闭区间包含。"))
                evidence.append(ev(f"artifacts/models.gff3:{p['line']}",f"父 mRNA ID={p['attrs']['ID']} 的闭区间为 {p['start']}–{p['end']}，seqid={p['seqid']}、strand={p['strand']}；无法包含第 {row['line']} 行 CDS。"))
            action='停止下游启动；依据可信注释来源修正受影响 CDS 坐标或其正确父关系/父区间，使每条子记录在同 seqid、同链的正确父闭区间内；重新检查完整层级和蛋白连接通过后再继续。不要仅按现有 CDS 任意扩展父区间。'
            uncertainties.append('越界事实确定；公开文件不能证明 CDS 坐标或父记录哪一项应修正，也不能推断历史上游事故。')
            secondary.append('Parent 均存在且类型、seqid、strand 一致，唯该 CDS 的包含失败；全部 CDS protein_id 与 FAA 记录双向精确连接通过。')
        else:
            raise AssertionError((case,errors))
    c=report['counts']
    evidence.append(ev('artifacts/record_counts.json:unique_cds_ids',f"字面 unique_cds_ids={c['unique_cds_ids']}，独立重算一致；CDS 行数 {c['cds_rows']} 是片段行数，不能代替蛋白条数。"))
    evidence.append(ev('artifacts/record_counts.json:protein_records',f"字面 protein_records={c['protein_records']}，完整 FAA 重算一致；全部七个字面计数字段均重算相符，蛋白 residues 合计 {c['protein_residues']}。"))
    partial_rows=[r['line'] for r in rows if r['attrs'].get('partial')=='true']
    if partial_rows:
        evidence.append(ev('task.md:9','题面明示允许 partial=true、多片段 CDS 与异构体，且不检查生物学全长或功能。'))
        secondary.append(f"partial=true 出现在 GFF 行 {', '.join(map(str,partial_rows))}；该属性本身不阻断，也不豁免 Parent/蛋白连接合同。")
    secondary.append(f"GFF {len(rows)} 条非注释特征记录、CDS {c['cds_rows']} 行、unique CDS ID {c['unique_cds_ids']}、unique protein_id {report['unique_protein_ids']}、FAA {c['protein_records']} 条和 {c['protein_residues']} residues 均已实际遍历；字面统计一致。")
    output=dict(verdict=verdict,observed_defect=defect,root_cause=cause,evidence=evidence,action=action,proposes_threshold_relaxation=False,proposes_skipping_check=False)
    assert set(output)==set(schema['required'])
    for key, value in output.items():
        spec=schema['properties'][key]
        if 'enum' in spec: assert value in spec['enum'], (case,key)
        if spec['type']=='boolean': assert type(value) is bool
        if spec['type']=='string': assert isinstance(value,str) and value.strip()
    assert output['evidence']
    for item in output['evidence']:
        assert set(item)=={'pointer','observation'}
        assert item['observation'].strip()
        assert re.match(schema['properties']['evidence']['items']['properties']['pointer']['pattern'], item['pointer'])
        file_name,location=item['pointer'].split(':',1)
        path=PACKETS/case/file_name
        contents=path.read_text(encoding='utf-8-sig')
        if location.isdigit(): assert 1<=int(location)<=len(contents.splitlines())
        else: assert location in json.loads(contents)
    cases[case]=dict(output=output,uncertainties=uncertainties,secondary_facts=secondary)
    notes.append(f"|{case}|{verdict}|{c['gene_rows']}/{c['mrna_rows']}/{c['exon_rows']}/{c['cds_rows']}|{c['unique_cds_ids']}/{report['unique_protein_ids']}/{c['protein_records']}|{c['protein_residues']}|{report['parent_edges']}|全七字段相符|")

notes += ['', '## 逐题次级事实与不确定性', '']
for case,content in cases.items():
    notes += [f"### {case}", '', f"判定：{content['output']['verdict']}；缺陷：{content['output']['observed_defect']}；文件级原因标签：{content['output']['root_cause']}。", '']
    notes += ['- '+f for f in content['secondary_facts']]
    notes += ['- 不确定性：'+u for u in content['uncertainties']] if content['uncertainties'] else ['- 范围内合同判定无未决不确定性；未对范围外生物学质量作判断。']
    notes += ['']
result=dict(review_kind='ai_blind_review',context='fork_none/public_only',reviewer_origin='Codex child agent inheriting parent model; exact provider model ID unavailable',cases=cases,methods=['独立读取公开题面合同；自行编写标准库 Python 解析全部记录并逐边/逐 CDS 行检查。','全 FAA token 双向精确匹配及所有字面计数独立重算。','人工审阅实际错误、关键原始行和全记录压缩显示；输出字段、枚举与证据位置校验。'],limitations=['AI 审查者，不是真人专家；没有操作系统强制隔离。','没有读取 gold、映射、旧评分、题库构建器或父会话。','公开文件不能支持历史上游原因、权威修复方向或范围外生物学质量。','schema 对 Parent ID 不匹配与层级错误原因标签有重叠，已在相关 uncertainty 说明。','未联网或调用另一个/付费模型；只运行本地文件检查。'])
(BASE/'reviewer_output.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(BASE/'reviewer_notes.md').write_text('\n'.join(notes)+'\n',encoding='utf-8')
print(json.dumps(dict(cases=len(cases),verdict_counts=dict(Counter(c['output']['verdict'] for c in cases.values())),validated='seven fields, types/enums, and all evidence locations',outputs=['reviewer_output.json','reviewer_notes.md']),ensure_ascii=False))
